-- MySQL dump 10.13  Distrib 5.1.67, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db_b110861cs
-- ------------------------------------------------------
-- Server version	5.1.67-0ubuntu0.10.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary table structure for view `distribution`
--

DROP TABLE IF EXISTS `distribution`;
/*!50001 DROP VIEW IF EXISTS `distribution`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `distribution` (
  `COUNT(*)` bigint(21),
  `score` int(11)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `marks`
--

DROP TABLE IF EXISTS `marks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marks` (
  `username` varchar(20) NOT NULL,
  `score` int(11) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marks`
--

LOCK TABLES `marks` WRITE;
/*!40000 ALTER TABLE `marks` DISABLE KEYS */;
INSERT INTO `marks` VALUES ('fds',4),('hemant',0),('shiv',2),('shrishty',1);
/*!40000 ALTER TABLE `marks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `new_users`
--

DROP TABLE IF EXISTS `new_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `new_users` (
  `username` varchar(80) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `password` varchar(80) DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `new_users`
--

LOCK TABLES `new_users` WRITE;
/*!40000 ALTER TABLE `new_users` DISABLE KEYS */;
INSERT INTO `new_users` VALUES ('101','nithinmohan94@gmail.com','101',0),('102','alexmathew.cyberx@gmail.com','102',0),('103','nithinmohan94@gmail.com','103',0),('104','aboobackervyd@gmail.com','104',0),('105','aboobackervyd@gmail.com','105',0),('106','pskirann@gmail.com','106',0),('107','akshaydaskolarikkal@gmail.com','107',0),('108','ltorvalds11@outlook.com','108',0),('109','ltorvalds11@outlook.com','109',0),('110','shabinmohd@gmail.com','110',0),('111','dwi.yn.anhysbys@live.com','111',0),('112','dwi.yn.anhysbys@live.com','112',0),('113','helofrancis@gmail.com','113',0),('114','umf2011@gmail.com','114',0),('115','allenmathew.is@gmail.com','115',0),('116','haritatineni93@gmail.com','116',0),('117','haritatineni93@gmail.com','117',0),('118','haritatineni93@gmail.com','118',0),('119','shafeeq94@gmail.com','119',0),('120','jayapriyaapai@gmail.com','120',0),('121','mihirrege2693@gmail.com','121',0),('122','haritatineni93@gmail.com','122',0),('123','kousthubraja@gmail.com','123',0),('124','kousthubraja@gmail.com','124',0),('125','pskirann@gmail.com','125',0),('126','pskirann@gmail.com','126',0),('127','helofrancis@gmail.com','127',0),('128','jayapriyaapai@gmail.com','128',0),('129','mohammedirfan1992@hotmail.com','129',0),('130','sananthanatarajan12@gmail.com','130',0),('131','srihari.daksh@gmail.com','131',0),('132','rbornrockers@gmail.com','132',0),('133','vigneshmanix@gmail.com','133',0),('134','vigneshmanix@gmail.com','134',0),('135','subhajyoti.de.4u@gmail.com','135',0),('136','subhajyoti.de.4u@gmail.com','136',0),('137','chinmoy406@gmail.com','137',0),('138','chinmoy406@gmail.com','138',0),('139','raj.sudheee@gmail.com','139',0);
/*!40000 ALTER TABLE `new_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `newone`
--

DROP TABLE IF EXISTS `newone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `newone` (
  `username` varchar(80) DEFAULT NULL,
  `tathvaid` varchar(80) DEFAULT NULL,
  `name` varchar(80) DEFAULT NULL,
  `phone` int(13) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `college` varchar(80) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `newone`
--

LOCK TABLES `newone` WRITE;
/*!40000 ALTER TABLE `newone` DISABLE KEYS */;
INSERT INTO `newone` VALUES ('101','87','nithin mohan',2147483647,'nithinmohan94@gmail.com','National Institute of Technology, Calicut'),('102','353','Alex Mathew',2147483647,'alexmathew.cyberx@gmail.com','Model Engineering College, B.M.C Post, Thrikkaara'),('103','87','nithin mohan',2147483647,'nithinmohan94@gmail.com','National Institute of Technology, Calicut'),('104','1019','Aboobacker MK',2147483647,'aboobackervyd@gmail.com','National Institute of Technology, Calicut'),('105','1019','Aboobacker MK',2147483647,'aboobackervyd@gmail.com','National Institute of Technology, Calicut'),('106','1065','kiran',2147483647,'pskirann@gmail.com','National Institute of Technology, Calicut'),('107','1245','akshay',2147483647,'akshaydaskolarikkal@gmail.com','Amal Jyothi College of Engineering, Kanjirapally'),('108','601','JIBRAN SHAIKH',2147483647,'ltorvalds11@outlook.com','National Institute of Technology, Calicut'),('109','601','JIBRAN SHAIKH',2147483647,'ltorvalds11@outlook.com','National Institute of Technology, Calicut'),('110','1344','Shabin Muhammed',2147483647,'shabinmohd@gmail.com','Mar Athanasius College of Engineering, Kothamangalam'),('111','1520','Yadhu',2147483647,'dwi.yn.anhysbys@live.com','Rajiv Gandhi Institute of Technology, Kottayam'),('112','1520','Yadhu',2147483647,'dwi.yn.anhysbys@live.com','Rajiv Gandhi Institute of Technology, Kottayam'),('113','1550','Francis Alexander',2147483647,'helofrancis@gmail.com','Amal Jyothi College of Engineering, Kanjirapally'),('114','1561','fazil',2147483647,'umf2011@gmail.com','TKM College of Engineering, Kollam'),('115','1565','Allen M Mathew',2147483647,'allenmathew.is@gmail.com','Amal Jyothi College of Engineering, Kanjirapally'),('115','1566','Joel Vargheese Joy',2147483647,'kuttan.joel@gmail.com','Amal Jyothi College of Engineering, Kanjirapally'),('116','146','T.Hari Durga',2147483647,'haritatineni93@gmail.com','National Institute of Technology, Calicut'),('117','146','T.Hari Durga',2147483647,'haritatineni93@gmail.com','National Institute of Technology, Calicut'),('118','146','T.Hari Durga',2147483647,'haritatineni93@gmail.com','National Institute of Technology, Calicut'),('119','1607','Shafeeq K',2147483647,'shafeeq94@gmail.com','NSS College of Engineering, Palakkad'),('120','1627','Jayapriya A',2147483647,'jayapriyaapai@gmail.com','Cochin University Of Science And Technology'),('121','1650','Mihir Rege',2147483647,'mihirrege2693@gmail.com','IIT Kharagpur'),('122','146','T.Hari Durga',2147483647,'haritatineni93@gmail.com','National Institute of Technology, Calicut'),('123','137','Deepak',2147483647,'dpk.nandan@gmail.com','National Institute of Technology, Calicut'),('123','835','Kousthub Raja',2147483647,'kousthubraja@gmail.com','National Institute of Technology, Calicut'),('124','1798','Deepak Nandan',2147483647,'dpk.nandan@gmail.com','National Institute of Technology, Calicut'),('124','1799','Kousthub Raja',2147483647,'kousthubraja@gmail.com','National Institute of Technology, Calicut'),('125','1065','kiran',2147483647,'pskirann@gmail.com','National Institute of Technology, Calicut'),('126','1065','kiran',2147483647,'pskirann@gmail.com','National Institute of Technology, Calicut'),('127','1550','Francis Alexander',2147483647,'helofrancis@gmail.com','Amal Jyothi College of Engineering, Kanjirapally'),('128','1627','Jayapriya A',2147483647,'jayapriyaapai@gmail.com','Cochin University Of Science And Technology'),('129','1937','Mohammed Irfan',2147483647,'mohammedirfan1992@hotmail.com','AWH Engineering College, Kozhikode'),('130','1952','Anantha Natarajan S',2147483647,'sananthanatarajan12@gmail.com','National Institute of Technology Trichy'),('131','2188','Srihari',2147483647,'srihari.daksh@gmail.com','National Institute of Technology, Calicut'),('132','2184','Renil Joseph',2147483647,'rbornrockers@gmail.com','Model Engineering College, B.M.C Post, Thrikkaara'),('133','1950','Vignesh M',2147483647,'vigneshmanix@gmail.com','National Institute of Technology Trichy'),('134','1950','Vignesh M',2147483647,'vigneshmanix@gmail.com','National Institute of Technology Trichy'),('135','2336','Subhajyoti De',2147483647,'subhajyoti.de.4u@gmail.com','National Institute of Technology, Calicut'),('136','2336','Subhajyoti De',2147483647,'subhajyoti.de.4u@gmail.com','National Institute of Technology, Calicut'),('137','2407','chinmoy kanta jena',2147483647,'chinmoy406@gmail.com','National Institute of Technology, Calicut'),('138','2407','chinmoy kanta jena',2147483647,'chinmoy406@gmail.com','National Institute of Technology, Calicut'),('139','275','sudheer babu bhadabhagni',2147483647,'raj.sudheee@gmail.com','JNT UNIVERSITY COLLEGE OF ENG. , ANANTAPUR');
/*!40000 ALTER TABLE `newone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `questions` (
  `question` varchar(150) NOT NULL,
  `opt1` varchar(80) DEFAULT NULL,
  `opt2` varchar(80) DEFAULT NULL,
  `opt3` varchar(80) DEFAULT NULL,
  `opt4` varchar(80) DEFAULT NULL,
  `answer` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questions`
--

LOCK TABLES `questions` WRITE;
/*!40000 ALTER TABLE `questions` DISABLE KEYS */;
INSERT INTO `questions` VALUES ('What is the significance of  sticky bit for directory ? ','after setting sticky bit any user can delete or rename that directory','Typically this is set on the /tmp directory to prevent ordinary users from delet','It can be set using chmod +c dir','any user can delete any file inside the folder even if sticky bit is set to its ',2),('Can we change the priority of a process in Linux ? ','Yes, using nice command we can run process at different priority levels.','we cant change priority level of a process, its defined by the OS ','renice is used to change priority level of already running program','A & C',4),('What is the octal code for permissions rwxrw-r--?','321','640','764','777',3),('Which of these is not a Linux flavor ?','Mandriva','Solaris','Xandros','Zenwalk',2),('What is a daemon in Linux ? ','A daemon is a type of program that runs unobtrusively in the background, rather ',' sshd is a daemon that services incoming SSH connections','Only option A is correct ','Both A & B',1),('What can you do to change runlevel of your system ?  ','Using telinit command ','changing values at /etc/inittab','using init command ','All the above',4),('Runlevel for system shutdown ? ','0','1','2','3',1),('Where can you find configuration  files that store system and application settings?','/usr','/home','/etc','/var',3),('Which variable is used to store PID of the current shell  ?','%$','$$','$1','$',2),('How wil you sort unique lines from a file f1 ? ','sort -d f1','sort -k f1','uniq | sort f1','sort f1 | uniq ',4),('How to count number of a\'s in file f2 ?','tr -cd \'1\' > f2 | wc -c','wc -c f2 \"a\"','cat f2 | tr -cd \'a\' | wc -c','tr -d \'a\' < f2 | wc -c ',3),('Which of these commands is used to find out the list of programs used by port number 80 ?  ','netstat -an | grep \':80\'','netstat -ap | grep \':80\'','netstat -\':80\'','netstat -at \":80\"',1),('What is the minimum number of partitions required to install Linux ? ','1','2','3','4',2),('What is the range of nice values ? ','0 to 40 ','-19 to 20 ','-20 to 19','0 to 20 ',3),('Which command is used to display the kernel name, version etc of your machine ? ','sysname','uname','sysinfo','uinfo',2),('How will you execute a script at each reboot ? ','0 0 0 0 /script','@reboot /script','@reboot -r /script','0 * * * /script',2),('What will you do to run /script at 5pm and 5am each day ?  ','17 05,00 * *  /script','05 17,05 * * * /script ','00 05,17 * * 0   /script','00 05,17 * * *  /script',4),('What will use to check if a download  link is broken without downloading it ?','wget --spider download-url','wget --broken download-url','wget --check download-url ','wget -b download-url ',1),('which of these commands helps you to view the cpu usage details by process  ? ','usage','top','nice ','cpusage',2),('Suppose you want to output the number of fields/columns corresponding to each row of a document ? ','awk \'{print \"Row No.\"NR,\"No of fields \",NF}\' doc-name','awk \'{print \"Row NO\" $1, \" No of Fields \" $2}\'','awk \'{print \"Row No.\"NF,\"No of fields \",NR}\' doc-name','awk \'{print \"Row NO\" $1, \" No of Fields \" $2}\'',1),('which of these wont shutdown the system ? ','shutdown -h now ','init 0','reboot -p','halt -w ',4),('What TCP/IP protocol is used for remote terminal connection service?','telnet ','ftp','http','udp',1),('What is equivalent to chmod 644 file?','chmod u=rw,go=x file','chmod u=rw,go=rx file','chmod u=rwx,go=x file','None of the above',4),('Which one is not equivalent to wc < in > out ?','wc > out < in','< in wc > out','< out wc > in','> out wc < in',0),('Which command is used to show full path of (shell) commands?','whatis','which','what','who',2),('Consider the executable file print, which is executed as \"$ ./print tathva technical fest\". What does argv[1][3] correspond to ? ','t','n','h','s',3),('Which of the following sections in manual covers system calls ? ','1','2','3','4',2),('which of the following is not a system call ? ','lseek ','getc','open','chmod',2),('Redirection in pipes can be achieved using ? ','tee','>','>>','lpr',1),('Which of these is not present in inode ?','Location of the file ','name of the file','Size of the file ','permission setting of the file ',2),('Which of these options will print â€œhowareyouâ€ as output? ','for some ; do echo -n $some ; done < how are you ','for n in how are you ; do echo -n $n ; done ','for n in how are you ; do echo  $n ; done ','for some ; do echo -n $some ; done  how are you ',2),('The command $ cd ./../.','Equivalent to cd','Does nothing','Equivalent to cd ..','None of the above ',3),('Which of the following receives input only from standard input ?','sed','awk ','grep','tr ',4),('which of these operation will result in error ? ','expr 7 * 8','expr 7 - 8','expr 7 + 8','expr 7 / 8',1),('which command is used to find commands using a keyword ?','appropos','find','search','grep -command',1),('Which of these will open http://tathva.org using a newly created command \'tathva\' in firefox? ','alias \'/usr/bin/firefox http://tathva.org\'','alias tathva=\'/usr/bin/firefox \'','alias tathva=\'/usr/bin/firefox http://tathva.org\'','None of the above ',3),('How will you change the name of the current host system to tathva ?','sysname tathva','hostname','sysname','hostname tathva',4),('Find all directories accessed under  home directory within the last day  ? ','find /home/ -type -f -atime +1','find /home/ -type -f -ctime -1','find /home/ -type -f -ctime +1','find /home/ -type -f -atime +1',4),('head -n $2 < $3 | tail -n +$1 #suppose that we execute this script with three arguments with three aruments and first two being 3 and 8 respectively  ','prints out 6 lines of code starting from line no 3','prints out 8 lines of code starting from line no 3','prints out 3 lines of code above line no 8','prints out 6 lines of code starting from line no 8',1),(' #! /bin/bash head -n $2 < $3 | tail -n +$1 #suppose that we execute this script with three arguments What should be passed as first two arguments in ','argument one = 5 , argument two = 50','argument one = 0 , argument two = 45','argument one = 0 , argument two = 50','argument one = 5 , argument two = 55',4),('Which of these will output 4 ?','k=5 j=12 [ $k = 4 -a $j -gt 5 ] echo $k  ','k=4 j=12 [ $k = 5 -a $j -gt 5 ] echo $k  ','k=4 j=12 [ $k = 5 -a $j -gt 5 ] echo $j  ','None of the above ',2),('Which of these will output 2 ?','a=\'expr 5 / 2\' echo $a  ','a=`expr 5 / 2` echo $a','a=`expr 5 / 2` echo $a','a=\'expr 5 / 2\' echo $a  ',3);
/*!40000 ALTER TABLE `questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `results`
--

DROP TABLE IF EXISTS `results`;
/*!50001 DROP VIEW IF EXISTS `results`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `results` (
  `username` varchar(20),
  `email` varchar(60),
  `status` int(1),
  `score` int(11)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `username` varchar(20) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(40) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('101','nithinmohan94@gmail.com','101',0),('102','alexmathew.cyberx@gmail.com','102',0),('103','nithinmohan94@gmail.com','103',0),('104','aboobackervyd@gmail.com','104',0),('105','aboobackervyd@gmail.com','105',0),('106','pskirann@gmail.com','106',0),('107','akshaydaskolarikkal@gmail.com','107',0),('108','ltorvalds11@outlook.com','108',0),('109','ltorvalds11@outlook.com','109',0),('110','shabinmohd@gmail.com','110',0),('111','dwi.yn.anhysbys@live.com','111',0),('112','dwi.yn.anhysbys@live.com','112',0),('113','helofrancis@gmail.com','113',0),('114','umf2011@gmail.com','114',0),('115','allenmathew.is@gmail.com','115',0),('116','haritatineni93@gmail.com','116',0),('117','haritatineni93@gmail.com','117',0),('118','haritatineni93@gmail.com','118',0),('119','shafeeq94@gmail.com','119',0),('120','jayapriyaapai@gmail.com','120',0),('121','mihirrege2693@gmail.com','121',0),('122','haritatineni93@gmail.com','122',0),('123','kousthubraja@gmail.com','123',0),('124','kousthubraja@gmail.com','124',0),('125','pskirann@gmail.com','125',0),('126','pskirann@gmail.com','126',0),('127','helofrancis@gmail.com','127',0),('128','jayapriyaapai@gmail.com','128',0),('129','mohammedirfan1992@hotmail.com','129',0),('130','sananthanatarajan12@gmail.com','130',0),('131','srihari.daksh@gmail.com','131',0),('132','rbornrockers@gmail.com','132',0),('133','vigneshmanix@gmail.com','133',0),('134','vigneshmanix@gmail.com','134',0),('135','subhajyoti.de.4u@gmail.com','135',0),('136','subhajyoti.de.4u@gmail.com','136',0),('137','chinmoy406@gmail.com','137',0),('138','chinmoy406@gmail.com','138',1),('139','raj.sudheee@gmail.com','139',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `distribution`
--

/*!50001 DROP TABLE IF EXISTS `distribution`*/;
/*!50001 DROP VIEW IF EXISTS `distribution`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`b110861cs`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `distribution` AS select count(0) AS `COUNT(*)`,`results`.`score` AS `score` from `results` group by `results`.`score` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `results`
--

/*!50001 DROP TABLE IF EXISTS `results`*/;
/*!50001 DROP VIEW IF EXISTS `results`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`b110861cs`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `results` AS select `u`.`username` AS `username`,`u`.`email` AS `email`,`u`.`status` AS `status`,`m`.`score` AS `score` from (`users` `u` join `marks` `m`) where (`u`.`username` = `m`.`username`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-10-14 20:09:36
