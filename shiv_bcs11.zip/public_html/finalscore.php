<html>
	<head><title>Tux of War - Scores</title>
	<link rel="stylesheet" href="style.css">
	</head>

	<body>
		<?php include('header.php'); ?>
		<div id="center"><div style='text-align:center;font-size:36px;margin-top:20px;'>The Final Score List</div>
		<table id="scoretable">
			<tr><th>Username</th><th>Score</th></tr>
<?php
	require_once('dbconnect.php');
	$result = mysql_query("select * from marks order by score desc");
	$data = mysql_fetch_array($result);
	
	do {
		echo "<tr><td>".$data['username']."</td><td>".$data['score']."</td></tr>";

	} while($data = mysql_fetch_array($result));
?>
		</table>
		</div>
	</body>
</html>
