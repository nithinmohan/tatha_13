<?php
	session_start();
	if ( isset($_SESSION['username'])) {
?>
<html>
	<head><title>Tux of War - Confirm </title><link rel="stylesheet" href="style.css">
	</head>

	<body>
		<?php include('header.php'); ?>
		<?php
			$q = $_GET['q'];
			if ($q) {
				echo "<div id='error'>Type the linux command to know your current username</div>";
			}
		?>
		<form action="test.php" method="post" onsubmit="return checkSub()">
			<table>
				<tr><td>Do you want to start the test?</td></tr>
				<tr><td>Type the command to know current username <input type="text" id="ans" name="ans"></td></tr>
				<tr><td><input type="submit" value="Start Test"></td></tr>
			</table>
		</form>
	</body>
	<script>
		var checkSub = function() {
			var ans = document.getElementById("ans").value;
			if(ans == "") {
				alert('You cannot proceed without entering the command!!');
				return false;
			}
			return true;
		}
	</script>
</html>
<?php
	} else {
		header('Location:index.php');
	}
?>
