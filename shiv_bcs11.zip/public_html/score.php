<?php
	session_start();
	if( isset($_SESSION['username']) AND isset($_SESSION['blastoff']) AND isset($_SESSION['score'])) {
		require_once('dbconnect.php');
?>
<html>
	<head><title>Tux of War - Score</title></head>
	<link rel="stylesheet" href="style.css">
	<body>
		<?php include('header.php'); ?>
		<div id="yourscore">Your score is <?php echo $_SESSION['score'];?></div>
		
		<a href="finalscore.php"> Click to see the final scores list</a>
	</body>
</html>
<?php
		$result = mysql_query("update users set status=2 where username='".$_SESSION['username']."'") or die(mysql_error());
		session_destroy();
	} else {
		if (isset($_SESSION['blastoff']) AND isset($_SESSION['score'])) {
			header('Location:confirm.php');
		} else {
			header('Location:index.php');
		}
	}

?>
