<?php
	$ans = $_POST['ans'];
	if( $ans != "whoami" ) {
		header('Location:confirm.php?q=invalid');
	}
	session_start();
	$_SESSION['blastoff'] = "true";
	if( isset($_SESSION['username'])) {
?>
	<?php
		require_once('dbconnect.php');
		$data = mysql_query("select * from questions");
		$row = mysql_fetch_array($data);
		$i = 0;
	?>
<html>
	<head><title>Tux of War - Round 1</title><link rel="stylesheet" href="style.css"></head>
	
	<body>
		<?php include('header.php'); ?>
		<form action="evaluate.php" method="post" onsubmit="return confirmSubmit()">
			<div id="problem-container">
		<?php
			do {
				echo "<div class='problem'>  ";
				echo "<h3>$i. ".$row['question']."</h3>";
				echo "<input type='radio' name='$i' id='q1$i' value='1'><label for='q1$i'>". $row['opt1']."</label><br>";
				echo "<input type='radio' name='$i' id='q2$i' value='2'><label for='q2$i'>". $row['opt2']."</label><br>";
				echo "<input type='radio' name='$i' id='q3$i' value='3'><label for='q3$i'>". $row['opt3']."</label><br>";
				echo "<input type='radio' name='$i' id='q4$i' value='4'><label for='q4$i'>". $row['opt4']."</label><br>";
				echo "</div>";
				$i = $i + 1;
			} while( $row = mysql_fetch_array($data));
	
		?>
				<br>
				<div style='text-align:center'><input type="submit" value="Finish Test"></div>
			</div>
		</form>
	</body>
	<script>
		var confirmSubmit = function() {
			var x = confirm('Do you want to finish the test?\nAfter submitting you won\'t be able to change the answers.');
			if(x)
				return true;
			else
				return false; 
		}
	</script>

</html>

<?php
	} else {
		header('Location:index.php');
	}
?>
