<?php
	$username = $_POST['username'];
	$password = $_POST['password'];
	if(($username == "") || ($password == "")) {
		header('Location:index.php?q=invalid');
	}
	//echo $username;
	//echo $password;	
	include('dbconnect.php');
	
	$result = mysql_query("select * from users where username='$username' and password='$password'") or die(mysql_error());
	$row = mysql_fetch_array($result);
	if(($row == NULL) OR ($row['status'] == 1)) {
		header('Location:index.php?q=invalid');
	}
	else {
		if( $row['status'] == 0) {
			session_start();
			$_SESSION['username'] = $username;
			$_SESSION['uptime'] = date();
			$result = mysql_query("update users set status=1 where username='$username'") or die( mysql_error());
			header('Location:confirm.php');
		} else if ( $row['status'] == 2) {
			header('Location:finalscore.php');
		}
	}

?>
