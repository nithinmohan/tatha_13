<?php
	mysql_connect("localhost","b110861cs","shiwam@athena");
	mysql_selectdb("db_b110861cs");

?>
