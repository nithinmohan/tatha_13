<?php
	session_start();
	$_SESSION['blastoff'] = "true";
	if( isset($_SESSION['username']) AND isset($_SESSION['blastoff'])) {
?>
	<?php
		require_once('dbconnect.php');
		$data = mysql_query("select answer from questions");
		$row = mysql_fetch_array($data);
		$i = 0;
		$score = 0;
		do {
			if( $_POST[$i]) {
				if( $_POST[$i] == $row['answer'] ) {
					$score = $score + 1;
				}
			}
			$i = $i + 1;
		} while ( $row = mysql_fetch_array($data));
		//$result = mysql_query("delete from marks where username='".$_SESSION['username']."'");	
		$result = mysql_query("insert into marks values('".$_SESSION['username']."',".$score.")");
		$_SESSION['score'] = $score;
		header('Location:score.php');
	?>

<?php
	} else {
		header('Location:index.php');
	}
?>
