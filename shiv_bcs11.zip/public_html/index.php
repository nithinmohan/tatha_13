<html>
	<head>
		<title>
			Tux of War - Login
		</title>
		<link rel="stylesheet" href="style.css">
	</head>
	<body>
		<?php include('header.php'); ?>
		<?php
			$q = $_GET['q'];
			if($q) {
				echo "<div class='error'>The login detials are invalid</div>";
			}

		?>
		<div id="info">
			Instructions Must be Followed strictly!
			<ol>	<li>Competition will start at 9:00 and will end at 9:45</li>
				<li>Your user name and password is your tathva <b>TEAM Id</B></li>
				<li>once You Are Here,Back OR Refresh Buttons are stricly Prohibited </li>
				<li> In case of Blunders , You may contact us @ SHIV: 09995896085 Or SHRISHTY: 07736205466</li>
				
			</ol>	
		</div>
		<div id="loginForm">
			<form action="authenticate.php" method="post" onsubmit="return checkForm()" >
				<table>
					<tr><td>Username :</td><td><input type="text" id="username" name="username"></td></tr>
					<tr><td>Password :</td><td><input type="password" id="password" name="password"></td></tr>
					<tr><td colspan="2"><input type="submit" value="Login"></td></tr>
				</table>
			</form>
			<br><br>
			<a href="finalscore.php"> Click to see the final scores list</a>
		</div>
	</body>
	<script>
		var checkForm = function() {
			var uname = document.getElementById("username").value;
			var password = document.getElementById("password").value;
			if ( (uname == "") || (password == "")) {
				alert('Please enter the details properly');
				return false;
			}
			return true;
		}
	</script>
</html>
